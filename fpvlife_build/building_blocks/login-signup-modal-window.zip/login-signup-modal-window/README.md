# Login/Signup Modal Window

A Pen created on CodePen.io. Original URL: [https://codepen.io/adventuresinmissions/pen/poWpWw](https://codepen.io/adventuresinmissions/pen/poWpWw).

This modal window allows users to login/signup into your website. Once opened, the user can easily switch from one form to the other, or select the reset password option. http://codyhouse.co/gem/loginsignup-modal-window/